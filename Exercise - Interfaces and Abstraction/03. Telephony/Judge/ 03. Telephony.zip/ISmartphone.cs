namespace Telephony;

public interface ISmartphone {
    public void Browse(string url);
}