namespace BorderControl;

public interface ICitizen {
    public string Name { get; }
    public int Age { get; }
    public string Id { get; }
}