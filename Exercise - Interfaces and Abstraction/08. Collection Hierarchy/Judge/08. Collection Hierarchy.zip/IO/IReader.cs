﻿namespace CollectionHierarchy.IO {
  public  interface IReader {
        public string ReadLine();
    }
}
