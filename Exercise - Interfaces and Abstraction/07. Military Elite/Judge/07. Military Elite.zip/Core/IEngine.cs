﻿namespace MilitaryElite.Core
{
   public interface IEngine
    {
        void Run();
    }
}
