﻿namespace ExplicitInterfaces.IO {
    public interface IReader {
        public string ReadLine();
    }
}
