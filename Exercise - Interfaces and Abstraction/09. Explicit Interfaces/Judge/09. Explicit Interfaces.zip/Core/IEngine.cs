﻿namespace ExplicitInterfaces.Core {
  public interface IEngine {
        public void Run();
    }
}
