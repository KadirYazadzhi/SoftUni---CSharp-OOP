namespace BirthdayCelebrations;

public interface IRobots {
    public string Model { get; }
    public string Id { get; }
}