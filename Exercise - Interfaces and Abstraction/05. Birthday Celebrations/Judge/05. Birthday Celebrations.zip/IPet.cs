namespace BirthdayCelebrations;

public interface IPet {
    public string Name { get; }
    public string Birthday { get; }
}