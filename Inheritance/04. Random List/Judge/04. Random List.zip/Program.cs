﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CustomRandomList {
    public class StartUp {
        public static void Main(string[] args) {
            
        }
    }
}