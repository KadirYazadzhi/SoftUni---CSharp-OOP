namespace Farm;

public class Animal {
    public static void Eat() {
        Console.WriteLine("eating...");
    }
}