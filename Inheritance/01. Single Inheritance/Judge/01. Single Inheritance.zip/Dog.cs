namespace Farm;

public class Dog : Animal{
    public static void Bark() {
        Console.WriteLine("barking...");
    }
}