namespace Farm;

public class Cat : Animal {
    public static void Meow() {
        Console.WriteLine("meowing...");
    }
}