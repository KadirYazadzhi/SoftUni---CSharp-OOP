namespace Farm;

public class Puppy : Dog {
    public static void Weep() {
        Console.WriteLine("weeping...");
    }
}