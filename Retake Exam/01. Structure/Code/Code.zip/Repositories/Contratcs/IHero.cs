namespace LegendsOfValor_TheGuildTrials.Repositories.Contratcs
{
    public interface IHero
    {
        string Name { get; }
        string RuneMark { get; }
        string GuildName { get; set; }
        int Power { get; set; }
        int Mana { get; set; }
        int Stamina { get; set; }

        void JoinGuild(IGuild guild);
        void Train();
        string Essence();
    }
} 