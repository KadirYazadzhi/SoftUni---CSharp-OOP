namespace LegendsOfValor_TheGuildTrials.Repositories.Contratcs
{
    public interface IGuild
    {
        string Name { get; }
        int Wealth { get; set; }
        IReadOnlyCollection<string> Legion { get; }
        bool IsFallen { get; set; }

        void RecruitHero(IHero hero);
        void TrainLegion(ICollection<IHero> heroesToTrain);
        void WinWar(int goldAmount);
        void LoseWar();
    }
} 