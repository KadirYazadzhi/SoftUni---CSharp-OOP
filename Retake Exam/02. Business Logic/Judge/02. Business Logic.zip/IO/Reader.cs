﻿using LegendsOfValor_TheGuildTrials.IO.Contracts;

namespace LegendsOfValor_TheGuildTrials.IO
{
    public class Reader : IReader
    {
        public string ReadLine() => Console.ReadLine();
    }
}
