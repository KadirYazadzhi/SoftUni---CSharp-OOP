namespace PlayersAndMonsters;

public class BladeKnight : DarkKnight {
    public BladeKnight(string name, int level) : base(name, level) {
        
    }
}