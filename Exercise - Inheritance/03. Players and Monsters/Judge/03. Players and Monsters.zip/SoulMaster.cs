namespace PlayersAndMonsters;

public class SoulMaster : DarkWizard {
    public SoulMaster(string name, int level) : base(name, level) {
        
    }
}