namespace PlayersAndMonsters;

public class DarkWizard : Wizard {
    public DarkWizard(string name, int level) : base(name, level) {
      
    }
}