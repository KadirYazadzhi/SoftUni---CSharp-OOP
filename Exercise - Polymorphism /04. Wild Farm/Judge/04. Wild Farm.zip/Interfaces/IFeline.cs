﻿namespace WildFarm.Interfaces;

public interface IFeline {
    public string Breed { get;}
}

