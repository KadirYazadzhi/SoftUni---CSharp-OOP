﻿namespace WildFarm.Interfaces;
public interface IMammal {
    public string LivingRegion { get;}
}

