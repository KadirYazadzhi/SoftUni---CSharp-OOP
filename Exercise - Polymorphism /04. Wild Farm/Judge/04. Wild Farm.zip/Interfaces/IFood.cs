﻿namespace WildFarm.Interfaces;
public interface IFood {
    public int Quantity { get;}
}

