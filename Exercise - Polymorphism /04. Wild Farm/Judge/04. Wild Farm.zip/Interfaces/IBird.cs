﻿namespace WildFarm.Interfaces;
public interface IBird {
    public double WingSize { get;}
}

