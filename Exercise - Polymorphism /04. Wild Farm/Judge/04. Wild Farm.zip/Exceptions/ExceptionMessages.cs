﻿namespace WildFarm.Exceptions;
public static class ExceptionMessages {
    public const string InvalidFoodException = "{0} does not eat {1}!";
}

