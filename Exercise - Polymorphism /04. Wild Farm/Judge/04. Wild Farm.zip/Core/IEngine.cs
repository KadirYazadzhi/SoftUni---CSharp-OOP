﻿namespace WildFarm.Core;
public interface IEngine {
    public void Run();
}

