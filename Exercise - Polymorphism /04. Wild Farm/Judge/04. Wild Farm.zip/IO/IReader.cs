﻿namespace WildFarm.IO;
public interface IReader {
    public string ReadLine();
}

