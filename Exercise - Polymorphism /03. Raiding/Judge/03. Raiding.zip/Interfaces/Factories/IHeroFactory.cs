namespace Raiding;

public interface IHeroFactory {
    IHero Create(string name);
}