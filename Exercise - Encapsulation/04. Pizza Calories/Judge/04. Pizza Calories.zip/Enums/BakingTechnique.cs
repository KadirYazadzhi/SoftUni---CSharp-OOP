﻿namespace PizzaCalories.Enums;

public enum BakingTechnique {
    Crispy,
    Chewy,
    Homemade
}