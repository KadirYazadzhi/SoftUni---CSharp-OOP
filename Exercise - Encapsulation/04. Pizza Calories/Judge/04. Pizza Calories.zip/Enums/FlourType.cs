﻿namespace PizzaCalories.Enums;

public enum FlourType {
    White,
    Wholegrain
}