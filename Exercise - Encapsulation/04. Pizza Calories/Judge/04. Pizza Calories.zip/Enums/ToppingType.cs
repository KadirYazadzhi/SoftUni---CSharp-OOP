﻿namespace PizzaCalories.Enums;

public enum ToppingType {
    Meat,
    Veggies,
    Cheese,
    Sauce
}